# BackEndEcommerce
npm i --save express
npm i --save cors
npm i --save mysql2
npm i --save bcrypt